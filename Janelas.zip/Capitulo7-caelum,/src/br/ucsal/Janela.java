package br.ucsal;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.*;

import javax.swing.*;

public class Janela extends JFrame implements ActionListener, MouseListener{
	
	private JButton botao1;
	private int local=0;
	
	 public Janela(){
		 super("Janela 1.0");
		 setSize(300, 300);
		 setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		 
		 //this.setLayout(new FlowLayout());
		this.setLayout(null);
		
		 
		/**
		 * JLabel rotulo = new JLabel("Texto");
		 
		 rotulo.setForeground(Color.BLUE);
		 
		 Font font = new Font("Verdana", Font.BOLD, 20);
		 rotulo.setFont(font);
		 this.add(rotulo);
	 */
		 
		 botao1 = new JButton("Botao 1");
		 botao1.addActionListener(this);
		 botao1.addMouseListener(this);
		 this.add(botao1);
		 botao1.setBounds(local, local, 150, 50);
		
		 setVisible(true);
		
	 }

	 
   @Override
    public void mouseEntered(MouseEvent e) {
    	if(local == 0){
    		local = 150;
    		botao1.setBounds(local, local, 150, 50);
    	}else{
    		local = 0;
    		botao1.setBounds(local, local, 150, 50);
    	}
    	
    }

	@Override
	public void actionPerformed(ActionEvent arg0) {
		System.out.println("Clicou!");
		
	}


	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	

}
