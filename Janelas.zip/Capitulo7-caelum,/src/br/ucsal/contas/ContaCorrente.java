package br.ucsal.contas;

public class ContaCorrente extends Conta {

}
