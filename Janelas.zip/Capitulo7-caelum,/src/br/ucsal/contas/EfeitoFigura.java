package br.ucsal.contas;

public class EfeitoFigura {

}
