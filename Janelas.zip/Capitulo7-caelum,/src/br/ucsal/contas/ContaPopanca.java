package br.ucsal.contas;

public class ContaPopanca extends Conta{

	  @Override
		public void atualuiza(int taxa){
		  super.atualuiza(taxa*2);
			saldo = saldo + (saldo * taxa) *2;
		}
	  
}
