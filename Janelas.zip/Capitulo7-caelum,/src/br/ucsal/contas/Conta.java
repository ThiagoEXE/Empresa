package br.ucsal.contas;

public class Conta {
	
	protected double saldo;
	
	public void atualuiza(int taxa){
		saldo = saldo + saldo * taxa;
	}

}
