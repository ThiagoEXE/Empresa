package br.ucsal;

public class TestaJanela {

	public static void main(String[] args) {
         new Janela();

	}

}
