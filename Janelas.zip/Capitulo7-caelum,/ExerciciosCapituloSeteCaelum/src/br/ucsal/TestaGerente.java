package br.ucsal;

public class TestaGerente {

	public static void main(String[] args) {

       Gerente gerente = new Gerente();
       
       gerente.setNome("Ary Regis");
       gerente.setCpf("1133344555");
       gerente.setNumeroDeFuncionariosGerenciados(10);
       gerente.setSalario(5000.0);
       gerente.setSenha(4321);
       System.out.println(gerente.getBonificacao());
	}

}
