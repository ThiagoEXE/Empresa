package br.ucsal;

public class Gerente extends Funcionario {

	String nome;
	String cpf;
	double salario;
	int senha;
	int numeroDeFuncionariosGerenciados;
	Funcionario[] funcionarios;


	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}

	public int getSenha() {
		return senha;
	}

	public void setSenha(int senha) {
		this.senha = senha;
	}

	public int getNumeroDeFuncionariosGerenciados() {
		return numeroDeFuncionariosGerenciados;
	}

	public void setNumeroDeFuncionariosGerenciados(int numeroDeFuncionariosGerenciados) {
		this.numeroDeFuncionariosGerenciados = numeroDeFuncionariosGerenciados;
	}

	public Funcionario[] getFuncionarios() {
		return funcionarios;
	}

	public void setFuncionarios(Funcionario[] funcionarios) {
		this.funcionarios = funcionarios;
	}
	
	public boolean autentica(int senha){
		if(this.senha == senha) {
			System.out.println("Acesso Permitido!!");
			return true;
		} else {
			System.out.println("Acesso Negado!!");
			return false;
		}
        
	}
	
	void adiciona(Funcionario funcionarios) {
		Funcionario funcionario = new Funcionario();
		funcionario.cpf = "062.394.235-64";


	}
	@Override
	public double getBonificacao() {
		  return getBonificacao() + 1000;
	 }
}
